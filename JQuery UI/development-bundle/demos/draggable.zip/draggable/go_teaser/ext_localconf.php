<?php
if (!defined ('TYPO3_MODE')) 	die ('Access denied.');
t3lib_extMgm::addPItoST43($_EXTKEY,'piTeaser/class.tx_goteaser_piTeaser.php','_piTeaser','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piProductTeaser/class.tx_goteaser_piProductTeaser.php','_piProductTeaser','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piHomeWhiteTeaser/class.tx_goteaser_piHomeWhiteTeaser.php','_piHomeWhiteTeaser','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piWhiteteaser2/class.tx_goteaser_piWhiteteaser2.php','_piWhiteteaser2','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piDarkteaser/class.tx_goteaser_piDarkteaser.php','_piDarkteaser','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piDarkteaser2/class.tx_goteaser_piDarkteaser2.php','_piDarkteaser2','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piLanguage/class.tx_goteaser_piLanguage.php','_piLanguage','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piServices/class.tx_goteaser_piServices.php','_piServices','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piHeading/class.tx_goteaser_piHeading.php','_piHeading','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piTeaserBoard/class.tx_goteaser_piTeaserBoard.php','_piTeaserBoard','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piContact/class.tx_goteaser_piContact.php','_piContact','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piLinks/class.tx_goteaser_piLinks.php','_piLinks','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piPresse/class.tx_goteaser_piPresse.php','_piPresse','CType',1);



t3lib_extMgm::addPItoST43($_EXTKEY,'piHeading/class.tx_goteaser_piHeading.php','_piHeading','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piHeading/class.tx_goteaser_piHeading.php','_piHeading','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piHeading/class.tx_goteaser_piHeading.php','_piHeading','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piHeading/class.tx_goteaser_piHeading.php','_piHeading','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piHeading/class.tx_goteaser_piHeading.php','_piHeading','CType',1);
?>