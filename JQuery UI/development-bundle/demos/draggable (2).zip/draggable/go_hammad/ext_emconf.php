<?php

########################################################################
# Extension Manager/Repository config file for ext: "go_teaser"
#
# Auto generated 24-04-2009 04:15
#
# Manual updates:
# Only the data in the array - anything else is removed by next write.
# "version" and "dependencies" must not be touched!
########################################################################

$EM_CONF[$_EXTKEY] = array(
	'title' => 'Gosign Teaser',
	'description' => '',
	'category' => 'fe',
	'author' => 'Gosign media.',
	'author_email' => 'mohsin@cassini.gosign.de',
	'shy' => '',
	'dependencies' => 'go_pibase',
	'conflicts' => '',
	'priority' => '',
	'module' => '',
	'state' => 'stable',
	'internal' => '',
	'uploadfolder' => 0,
	'createDirs' => '',
	'modify_tables' => '',
	'clearCacheOnLoad' => 0,
	'lockType' => '',
	'author_company' => 'Gosign media. GmbH',
	'version' => '1.1.0',
	'constraints' => array(
		'depends' => array(
			'go_pibase' => '1.2.1-0.0.0'
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
	'_md5_values_when_last_written' => 'a:10:{s:12:"ext_icon.gif";s:4:"461a";s:17:"ext_localconf.php";s:4:"8d5f";s:14:"ext_tables.php";s:4:"eabc";s:14:"ext_tables.sql";s:4:"627d";s:24:"ext_typoscript_setup.txt";s:4:"940c";s:31:"lib/class.user_go_tcamodify.php";s:4:"bb1b";s:16:"locallang_db.xml";s:4:"de57";s:39:"piTeaser/class.tx_goteaser_piTeaser.php";s:4:"7bda";s:22:"piTeaser/template.html";s:4:"70de";s:16:"res/piTeaser.css";s:4:"d41d";}',
	'suggests' => array(
	),
);

?>