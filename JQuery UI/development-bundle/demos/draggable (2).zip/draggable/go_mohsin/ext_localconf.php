<?php
if (!defined ('TYPO3_MODE')) 	die ('Access denied.');

t3lib_extMgm::addPItoST43($_EXTKEY,'piZeshaan/class.tx_gomohsin_piZeshaan.php','_piZeshaan','CType',1);
t3lib_extMgm::addPItoST43($_EXTKEY,'piBublu/class.tx_gomohsin_piBublu.php','_piBublu','CType',1);
?>